function About() {
  return <div>ini adalah halaman about</div>;
}

export default About;
