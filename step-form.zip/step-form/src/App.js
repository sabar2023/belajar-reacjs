function App() {
  return (
   
    <div className="steps">
      <div className="numbers">
        <div className="">1</div>
        <div className="">2</div>
        <div className="">3</div>
      </div>
      <p className="message">Hello world</p>
    </div>
    
    <p className="message">Step: Dreams</p>
    <div className="buttons">
      <button style={{ backgroundColor: "#526082", color:"#fff"}}>Prev</button>
      <button style={{ backgroundColor: "#526082", color:"#fff"}}>Next</button>
      </div>
    </div>
   
  );
}

export default App;
