function App() {
  return (
    <div className="App">
      <Logo />
      <Form />
      <Checklist />
      <Stats />
    </div>
  );
}

function logo() {
  return <span className="logo">Go Check</span>;
}

function Form() {
  return (
    <div className="add-Form">
      <h3>ada yang mau kamu catat</h3>
    </div>
  );
}

function Checklist() {
  return (
    <div className="List">
      <ul>
        <li>Makan</li>
        <li>Tidur</li>
      </ul>
    </div>
  );
}

function Stats() {
  return (
    <footer className="stats">
      <span>Kamu punya catatan baru yagn di Checklist</span>
    </footer>
  );
}

export default App;
