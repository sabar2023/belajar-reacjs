import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import data from "./data.js";

function App() {
  return (
    <div className="container">
      <Header />
      <Menu />
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <h1
      style={{
        color: "red",
        fontSize: "50px",
      }}
    >
      Warteg Mang udin
    </h1>
  );
}

function Menu() {
  return (
    <main className="menu">
      <h2>Menu kita</h2>
      <ul className="foods">
        {data.map((food) => (
          <Food foodObj={food} />
        ))}
      </ul>
    </main>
  );
}

function Footer() {
  const hour = new Date().getHours();
  const jamBuka = 10;
  const jamTutup = 22;

  if (hour < jamBuka || hour > jamTutup) {
    alert("warteg mang udin tutup");
  } else {
    alert("warteg mang udin Buka");
  }

  return (
    <footer className="footer">
      {new Date().getFullYear()} warung mang udin | jam buka {jamBuka} - jam tutup {jamTutup}
    </footer>
  );
}

function Food(props) {
  return (
    <li className="food">
      <img src={Props.foodObj.foto} alt={props.foodObj.nama} width="100" height="70" />
      <div>
        <h3>{props.foodObj.nama}</h3>
        <p>{props.foodObj.deskripsi}</p>
        <span>{props.foodObj.harga}</span>
      </div>
    </li>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
